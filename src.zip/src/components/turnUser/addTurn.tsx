
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Autocomplete, TextField } from '@mui/material';
import Cookies from 'js-cookie';
import jwt, { JwtPayload } from 'jsonwebtoken';


interface Treatment {
  date: Date;
  time: Date;
  patientName: string;
  name: string;
  duration: number;
  email: string
}

export const AddTreatmentForm: React.FC = () => {
  const [optionsTreatment, setOptionsTreatment] = useState([]);

  const [turns, setTurns] = useState([]);
  const [freeQueues, setFreeQueues] = useState([]);
  const [treatment, setTreatment] = useState<Treatment>({
    date: new Date(Date.now()),
    time: new Date('12:00'),
    patientName: 'ayala',
    name: 'גבות',
    duration: 10,
    email: '',
  });


  const handleInputChange = (value: any, name: any) => {

    setTreatment({ ...treatment, [name]: value });
    console.log(treatment);
  };
  const fetchFreeQueues = async () => {
    console.log('hi');
    
    const response = await axios.get('http://localhost:3000/turns/free-queues', {
      params: {
        // Replace with the desired date
        duration:treatment.duration,
         date:treatment.date
      },
    });
    setFreeQueues(response.data);
  };

  const handleFormSubmit = async (event: React.FormEvent) => {
    event.preventDefault();

    
    
    const token = Cookies.get('token');
    //  if(token){
    //   const secretKey = 'SECRET';
    //   const decodedToken = jwt.verify(token, secretKey);

    //  // החזרת הערך של העוגיה 'token'
      
    // try {
    //   const decodedToken = jwt.verify(token, secretKey);
    //   console.log('Decoded Token:', decodedToken);
    // } catch (error) {
    //   console.error('Token verification failed:', error);
     
    // }
//}

    const headers = {
      'Content-Type': 'application/json',
      'authorization': `Bearer ${token}`
    };
    try {
      console.log(treatment);
      const duration = treatment.duration;
      // const exsitTurns = await axios.get('http://localhost:3000/turns/getByDate/'+treatment.date);
      fetchFreeQueues();

      await axios.post('http://localhost:3000/turns/addTreatment', treatment, { headers }); // Change the endpoint '/api/treatments' to match your Nest.js server route for adding treatments
      // Reset the form after successful submission
      setTreatment({
        date: new Date(),
        time: new Date(),
        patientName: '',
        name: '',
        duration: 0,
        email: '',
      });
      alert('Treatment added successfully!');
    } catch (error) {
      console.error('Error adding treatment:', error);
      alert('Failed to add treatment. Please try again later.');
  
  
    }
  };



  useEffect(() => {
 
    // Make an Axios request to retrieve the turn types from MongoDB
    axios.get('http://localhost:3000/turns-type')
      .then((response) => {
        console.log(response.data)

        const allTurns = response.data;
        setTurns(allTurns);

        const typeOfTurns = allTurns.map((obj: any) => obj.typeOfTurn);
        setOptionsTreatment(typeOfTurns);
        console.log(optionsTreatment);

      })
      .catch((error) => {
        console.error('Error retrieving turn types:', error);
      });
  }, []);

  const handleTreatmentChange = (event: any, value: any) => {
    let duration = 0;
    turns.forEach((turn: any) => {
      if (turn.typeOfTurn === value) {
        duration = turn.duration;
      }
    });
    setTreatment({ ...treatment, ['name']: value, ['duration']: duration });
  }
  return <>
    <div>
      <h1>Free Queues</h1>
      <ul>
        {freeQueues.map((queue) => (
          <li key={queue}>{queue}</li>
        ))}
      </ul>
    </div>
    <form onSubmit={handleFormSubmit}>
      <div>
        <TextField id="outlined-basic" variant="outlined"
          sx={{width:300}}
          type="date"
          name="date"
          value={treatment.date}

          onChange={(e) => handleInputChange(e.target.value, e.target.name)}
          // required
        />
      </div>
      <div>
        <TextField id="outlined-basic2" variant="outlined"
        sx={{width:300}}
          type="time"
          name="time"
          value={treatment.time}
          onChange={(e) => handleInputChange(e.target.value, e.target.name)}
          // required
        />
      </div>
      <div>
      <TextField id="outlined-basic3" label="Name" variant="outlined"
        sx={{width:300}}
          type="text"
          name="patientName"
          value={treatment.patientName}
          onChange={(e) => handleInputChange(e.target.value, e.target.name)}
          // required
        />
      </div>
      <Autocomplete
        options={optionsTreatment}
        sx={{width:300 ,marginLeft:'40.3%'}}
        onChange={handleTreatmentChange}
        renderInput={(params) => (
          <TextField {...params} label="NameOfTURN" variant="outlined" />
        )}
      />

      <div>

        <TextField id="outlined-basic4" label="email" variant="outlined"
          sx={{width:300}}
          type="text"
          name="email"
          value={treatment.email}
          onChange={(e) => handleInputChange(e.target.value, e.target.name)}
          // required
        />
      </div>
      <button type="submit">Add Treatment</button>
    </form>
  </>

};