import * as React from 'react';
import Paper from '@mui/material/Paper';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TablePagination from '@mui/material/TablePagination';
import TableRow from '@mui/material/TableRow';
import axios from 'axios';
//import { AccessAlarm, Key, ThreeDRotation } from '@mui/icons-material';
import DeleteIcon from '@mui/icons-material/Delete';
import { green } from '@mui/material/colors';
import api from '../api';


interface Column {
  id: 'date' | 'time' | 'managerTurn' |'name'| 'TurnType' | 'delete';
  label: string;
  minWidth?: number;
  align?: 'right';
  format?: (value: number) => string;
}


const columns: Column[] = [
  { id: 'date', label: 'date', minWidth: 170 },
  { id: 'time', label: 'time', minWidth: 170 },
  {
    id: 'managerTurn',
    label: 'ManagerTurn',
    minWidth: 170,
    align: 'right',
    format: (value: number) => value.toLocaleString('en-US'),
  },
  { id: 'delete', label: 'cancel', minWidth: 170 },
  { id: 'name', label: 'name', minWidth: 170 },
];

// interface Data {
//   date: string;
//   time: string;
//   ManagerTurn: string;

// }

//rows.forEach(e => );
///{ createData('India', 'IN', 1324171354, 3287263),}

export const TurnUser = () => {
  //let rows:any = [];
  const [view, setView] = React.useState(0);
  const [page, setPage] = React.useState(0);
  const [rowsPerPage, setRowsPerPage] = React.useState(10);
  const [rows, setRow] = React.useState([]);
  //const [showTable, setShowTable] = React.useState(false);

  async function getData(event: any) {
    const email = localStorage.getItem('myData');
    console.log(email);
    
    
    const { data } = await api.get("http://localhost:3000/turns/");
    console.log(data)

    const filterData = data.map((d: any) => {
      return {
        id:d._id,
        date: d.date,
        time: d.time,
        name:d.name,
        caregiver: null
      }
    })
    setRow(filterData)
    setView(1)
  }
  const deleteItem = (index: any) => {
    // event.preventDefault();
    // const key=event.currentTarget.parentNode.getAttribute("insex");
    // console.log(event);
    const deletedRow = rows[index];

    const id =deletedRow['id'];
    console.log(id);
    axios.delete('http://localhost:3000/turns/delete/'+id)
      .then(()=>{
        rows.splice(index, 1);
      
        // Update the state or re-render the table
        // For example, if you are using React with hooks:
        setRow([...rows]);
      }
      )
      .catch((error) => {
        console.log(error)
      }
      )
  }

  // const handleCloseTable = () => {
  //   setShowTable(true);
  // };


  const handleChangePage = (event: unknown, newPage: number) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event: React.ChangeEvent<HTMLInputElement>) => {
    setRowsPerPage(+event.target.value);
    setPage(0);
  };

  return (
    <>
      <button onClick={getData}>הצג את התורות שלי</button>
      {view == 1 && (
        <Paper sx={{ width: '100%' }}>
          <TableContainer sx={{ maxHeight: 440 }}>
            <Table stickyHeader aria-label="sticky table">
              <TableHead>
                <TableRow>
                  {columns.map((column) => (
                    <TableCell
                      key={column.id}
                      align={column.align}
                      style={{ top: 57, minWidth: column.minWidth }}
                    >
                      {column.label}

                    </TableCell>
                  ))}
                </TableRow>
              </TableHead>
              <TableBody>
                {rows
                  .map((row, index) => {
                    return (
                      <TableRow key={index} hover role="checkbox" tabIndex={-1} >
                        {columns.map((column) => {
                          const value = row[column.id];
                          return (
                            <TableCell key={column.id} align={column.align} >
                              {column.format && typeof value === 'number'
                                ? column.format(value)
                                : value}
                              {column.id == 'delete' &&
                                  <DeleteIcon onClick={() => deleteItem(index)} />

                              }
                            </TableCell>

                          );
                        })}
                      </TableRow>
                    );
                  })}

              </TableBody>
            </Table>
          </TableContainer>
          <TablePagination
            rowsPerPageOptions={[10, 25, 100]}
            component="div"
            count={rows.length}
            rowsPerPage={rowsPerPage}
            page={page}
            onPageChange={handleChangePage}
            onRowsPerPageChange={handleChangeRowsPerPage}
          />
        </Paper>)
      }
    </>
  );
}
