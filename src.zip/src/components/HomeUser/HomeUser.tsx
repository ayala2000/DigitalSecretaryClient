import * as React from 'react';
 
export const Home = () =>{
    return(<>
    hello Digital Secretary</>);
};