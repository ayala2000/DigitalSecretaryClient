// ////import React, { Fragment } from 'react';
// //import { sliceEvents, createPlugin } from '@fullcalendar/core';
// import React, { Fragment, ReactNode } from 'react';
// import { sliceEvents, createPlugin, ViewConfigInput, ViewProps } from '@fullcalendar/core';
// import { ConsumerProps } from 'preact';
   

// class CustomView extends React.Component {

//     CustomViewrender(props:any) {
//     let segs = sliceEvents(props, true); // allDay=true

//     return (
//       <Fragment>
//         <div className='view-title'>
//           {props.dateProfile.currentRange.start.toUTCString()}
//         </div>
//         <div className='view-events'>
//           {segs.length} events
//         </div>
//       </Fragment>
//     );
//   }

// }

// export default createPlugin(
//     views: {
//         custom: CustomView as ViewConfigInput<ViewProps>
//       }
// );