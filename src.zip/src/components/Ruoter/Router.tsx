import React from 'react';
import { BrowserRouter as Router, Link, Route } from 'react-router-dom';

import Home from './Home';
import About from './About';
import Contact from './Contact';

function Navbar() {
  return (
    <Router>
      <nav>
        <ul>
          <li>
            <Link to="/">דף הבית</Link>
          </li>
          <li>
            <Link to="/about">אודות</Link>
          </li>
          <li>
            <Link to="/contact">צור קשר</Link>
          </li>
        </ul>
      </nav>

      <Route path="/"  Component={Home} />
      <Route path="/about" Component={About} />
      <Route path="/contact" Component={Contact} />
    </Router>
  );
}

export default Navbar;
