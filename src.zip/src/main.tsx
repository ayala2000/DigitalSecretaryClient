import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.tsx'
import './index.css'
// import { Login } from './components/Login/Login.tsx'
// import { Register } from './components/Register/Register.tsx';
import { BrowserRouter } from 'react-router-dom';
import Navbar from './components/Ruoter/navlin.tsx';
import {Home} from './components/HomeUser/HomeUser.tsx';
import ResponsiveAppBar from './components/Ruoter/navlin.tsx';


ReactDOM.createRoot(document.getElementById('root') as HTMLElement).render(
  <React.StrictMode>
    <BrowserRouter>
      <ResponsiveAppBar/>
      <App/>
    </BrowserRouter>
  </React.StrictMode>,
)
