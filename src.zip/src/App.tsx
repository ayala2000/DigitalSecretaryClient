//import { useState } from 'react'
import './App.css';
import { Login } from "../src/components/Login/Login";
import { Register } from './components/Register/Register';
import { TurnUser } from './components/turnUser/turn';
import { Route, Routes } from 'react-router-dom';
import { AddTreatmentForm } from './components/turnUser/addTurn';
import DemoApp from './components/Calendar/calendar';
import Navbar from './components/Ruoter/navlin';

import { Switch } from '@mui/material';
import {Home} from './components/HomeUser/HomeUser';
import ResponsiveAppBar from './components/Ruoter/navlin';
import RecipeReviewCard from './components/User/blog';


function App() {
  return (
  <>
  
    <Routes>
      <Route path="/" element={<Login />} />
      {/* <Route index element={<Register />} /> */}
      <Route path="/register" element={<Register />}/>
      <Route path="/turns" element={<TurnUser />}/>
      <Route path="Blog" element={<RecipeReviewCard />} />
      <Route path="/addTurn" element={<AddTreatmentForm />} />
      <Route path="/calendar" element={<DemoApp />} />
      <Route path="/Home" element={<Home />} />
    </Routes>

  </>
    //  <Switch>
    //  <Route exact path="/" component={HomePage} />
    //   <Route path="/about" component={About} />
    // </Switch>
  );




}

export default App
